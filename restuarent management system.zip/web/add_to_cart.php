<?php
include 'connectdb.php';
session_start();

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['userId']) && isset($data['itemName']) && isset($data['price'])) {
    $userId = $data['userId'];
    $itemName = $data['itemName'];
    $price = $data['price'];
    
    $sql = "INSERT INTO cart (user_id, item_name, price) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isd", $userId, $itemName, $price);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add item to cart']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid data received']);
}
?>