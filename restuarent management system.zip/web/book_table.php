<?php
include 'connectdb.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $persons = $_POST['person'];
    $date = $_POST['reservation-date'];
    $time = $_POST['time'];
    $message = $_POST['message'];

    $sql = "INSERT INTO table_bookings (name, phone, persons, booking_date, booking_time, message) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $name, $phone, $persons, $date, $time, $message);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Table booked successfully! We will contact you shortly.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to book table. Please try again.']);
    }

    $stmt->close();
    $conn->close();
}
?>